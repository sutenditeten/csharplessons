﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Section3
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
