﻿namespace Section14.Final_Exam_1
{
    public abstract class BasePage
    {
        public abstract string PageName { get; }
    }
}