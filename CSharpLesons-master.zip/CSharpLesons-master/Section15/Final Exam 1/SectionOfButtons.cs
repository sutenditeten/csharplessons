﻿namespace Section14.Final_Exam_1
{
    public class SectionOfButtons
    {
        public Element Button { get; set; }
    }
}