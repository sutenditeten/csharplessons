﻿using System;

namespace Section14.Final_Exam_1
{
    public class SectionOfRandomStuff
    {
        public void FillForm()
        {
            //I fill out the form
            Console.WriteLine("Fill out form");
        }
    }
}