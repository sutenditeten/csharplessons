﻿namespace Section14.Final_Exam_1
{
    public class SectionOfSocialMedia
    {
        public Element TwitterButton { get; set; }
        public Element FacebookButton { get; set; }
    }
}