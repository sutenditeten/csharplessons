﻿namespace section15
{
    public class SectionOfSocialMedia
    {
        public Element TwitterButton { get; set; }
        public Element FacebookButton { get; set; }
    }
}