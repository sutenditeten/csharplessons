﻿namespace section15
{
    public class SectionOfButtons
    {
        public Element Button { get; set; }
    }
}