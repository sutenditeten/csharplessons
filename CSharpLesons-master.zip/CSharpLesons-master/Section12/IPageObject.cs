﻿namespace Section12
{
    internal interface IPageObject
    {
        string PageName { get; }
    }
}