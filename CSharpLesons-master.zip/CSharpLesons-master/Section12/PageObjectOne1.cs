﻿namespace Section12
{
    internal class PageObjectOne : IPageObject
    {
        public string PageName => "Page Name 1";
    }
}