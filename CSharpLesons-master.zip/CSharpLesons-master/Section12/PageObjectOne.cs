﻿namespace Section12
{
    internal class PageObjectTwo : IPageObject
    {
        public string PageName => "Page Name 2";
    }
}