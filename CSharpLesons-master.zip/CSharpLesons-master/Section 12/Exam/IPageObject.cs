﻿namespace Section12.Exam
{
    internal interface IPageObject
    {
        string PageName { get; }
    }
}