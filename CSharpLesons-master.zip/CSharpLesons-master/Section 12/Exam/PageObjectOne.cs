﻿namespace Section12.Exam
{
    internal class PageObjectOne : IPageObject
    {
        public string PageName => "Page Name 1";
    }
}