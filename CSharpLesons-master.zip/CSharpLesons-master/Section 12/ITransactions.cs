﻿namespace Section12
{
    interface ITransactions
    {
        double getAmount();
    }
}
