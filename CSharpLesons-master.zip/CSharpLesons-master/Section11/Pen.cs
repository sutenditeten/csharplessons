﻿public sealed class Pen 
{

    public Pen(string type)
    {
        Type = type;
    }

    public string Type
    {
        get;
        set;
    }
}