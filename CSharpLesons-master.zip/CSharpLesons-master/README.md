# CSharpLessons

[![Build status](https://nadvolodkin.visualstudio.com/UltimateQA/_apis/build/status/CSharpLessons)](https://nadvolodkin.visualstudio.com/UltimateQA/_build/latest?definitionId=-1)

A repository for C# exercises that we study from the Complete Selenium WebDriver course.
https://www.udemy.com/selenium-with-c/
